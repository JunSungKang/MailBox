# mail-server release-1.0.0

## 포함 항목

- `mail-smtp-receiver:1.0.0`
- `mail-imap-mailbox:1.0.0`
- `mail-webmail-ui:1.0.0`
- 실행용 `compose.yml`
- 기본 환경변수 파일 `.env.example`
- 수신 주소 관리 스크립트 `scripts/mail-user-add.sh`
- 수신 주소 map `config/postfix/virtual-mailbox-accounts`

## 실행

```bash
cp .env.example .env
docker compose up -d
```

이미지를 Registry에서 받을 경우 `.env`의 `IMAGE_REGISTRY`를 설정한다.

```dotenv
IMAGE_REGISTRY=ghcr.io/<owner>
IMAGE_TAG=1.0.0
```

## 주의

- 이 패키지는 소스 코드를 포함하지 않는다.
- `docker compose build` 없이 이미지를 실행하는 구성을 사용한다.
- 기존 데이터는 Docker volume `mailbox-store`, `smtp-queue-store`, `webmail-data-store`에 보관된다.
