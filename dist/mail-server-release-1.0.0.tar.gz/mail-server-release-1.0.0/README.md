# Mail Server Release 1.0.0

소스 코드 없이 컨테이너 이미지만 실행하는 배포 패키지입니다.

## 구성

```text
Internet SMTP
  -> mail-smtp-receiver
     -> mailbox-store
        -> mail-imap-mailbox
        -> mail-webmail-ui
```

## 실행

```bash
cp .env.example .env
docker compose up -d
```

Registry 이미지를 사용할 경우 `.env`에서 다음 값을 수정합니다.

```dotenv
IMAGE_REGISTRY=ghcr.io/<owner>
IMAGE_TAG=1.0.0
```

`IMAGE_REGISTRY`가 비어 있으면 로컬 Docker 이미지 `mail-smtp-receiver:1.0.0`, `mail-imap-mailbox:1.0.0`, `mail-webmail-ui:1.0.0`을 사용합니다.

## 포트

- Web UI: `http://localhost:18080`
- SMTP: `localhost:25`
- IMAP: `localhost:143`

## 기본 계정

- IMAP 사용자: `mailbox`
- IMAP 비밀번호: `@@`
- 기본 발신 주소: `mailbox@ds-mail.p-e.kr`

## 수신 주소 관리

수신 가능한 주소는 `config/postfix/virtual-mailbox-accounts`에서 관리합니다.

```bash
scripts/mail-user-add.sh list
scripts/mail-user-add.sh add alice
scripts/mail-user-add.sh remove alice
```

## 운영 명령

```bash
docker compose ps
docker compose logs -f mail-smtp-receiver
docker compose logs -f mail-imap-mailbox
docker compose logs -f mail-webmail-ui
```

## 데이터

메일과 웹 UI 데이터는 Docker volume에 저장됩니다.

- `mailbox-store`
- `smtp-queue-store`
- `webmail-data-store`

컨테이너만 내릴 때:

```bash
docker compose down
```

메일 데이터까지 삭제할 때:

```bash
docker compose down -v
```
